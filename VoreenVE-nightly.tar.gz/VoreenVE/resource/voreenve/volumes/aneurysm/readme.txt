This data was provided and is owned by the research group of Verena Hoerr, Jena, 2020.
Redistribution allowed if this acknowledgement is distributed as well.
