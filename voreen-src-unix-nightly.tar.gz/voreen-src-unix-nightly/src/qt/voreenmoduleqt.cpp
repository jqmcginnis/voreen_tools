/***********************************************************************************
 *                                                                                 *
 * Voreen - The Volume Rendering Engine                                            *
 *                                                                                 *
 * Copyright (C) 2005-2021 University of Muenster, Germany,                        *
 * Department of Computer Science.                                                 *
 * For a list of authors please refer to the file "CREDITS.txt".                   *
 *                                                                                 *
 * This file is part of the Voreen software package. Voreen is free software:      *
 * you can redistribute it and/or modify it under the terms of the GNU General     *
 * Public License version 2 as published by the Free Software Foundation.          *
 *                                                                                 *
 * Voreen is distributed in the hope that it will be useful, but WITHOUT ANY       *
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR   *
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.      *
 *                                                                                 *
 * You should have received a copy of the GNU General Public License in the file   *
 * "LICENSE.txt" along with this file. If not, see <http://www.gnu.org/licenses/>. *
 *                                                                                 *
 * For non-commercial academic use see the license exception specified in the file *
 * "LICENSE-academic.txt". To get information about commercial licensing please    *
 * contact the authors.                                                            *
 *                                                                                 *
 ***********************************************************************************/

#include "voreen/qt/voreenmoduleqt.h"

namespace voreen {

const std::string VoreenModuleQt::loggerCat_("voreen.qt.VoreenModuleQt");

VoreenModuleQt::VoreenModuleQt(const std::string& modulePath)
    : VoreenModule(modulePath)
{}

VoreenModuleQt::~VoreenModuleQt() {
    //will be deleted by qt (hopefully)
    /*for(size_t i = 0; i < customMenuEntities_.size(); i++)
        delete customMenuEntities_[i];*/

    customMenuEntities_.clear();
}

const std::vector<VoreenQtMenuEntity*>& VoreenModuleQt::getCustomMenuEntities() const {
    return customMenuEntities_;
}

void VoreenModuleQt::registerCustomMenuEntity(VoreenQtMenuEntity* entity) {
    tgtAssert(entity, "null pointer passed");
    customMenuEntities_.push_back(entity);
}

} // namespace
